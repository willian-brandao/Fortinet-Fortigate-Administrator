# Fortigate Administrator

# System and Networks Settings

## Objectives

[Configure Fortigate on factory default settings](https://www.notion.so/Configure-Fortigate-on-factory-default-settings-25d7825c32e9806abd95c72543440319?pvs=21)

- Configure Fortigate on factory as the DHCP server
- Configure and Control administrator access to Fortigate
- Back up and restore system configuration files
- Upgrade Fortigate firmware
- Check and verify Fortiguard licenses